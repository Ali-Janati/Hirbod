<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_CHARSET', 'utf8mb4');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "خطا در اتصال به پایگاه داده"]);
    exit;
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function requireAuth() {
    global $pdo;
    $token = $_GET['token'] ?? '';
    if (!$token) {
        $body = json_decode(file_get_contents("php://input"), true);
        $token = $body['token'] ?? '';
    }
    if (!$token) { jsonResponse(["error" => "توکن الزامی است"], 401); }
    $stmt = $pdo->prepare("SELECT * FROM tokens WHERE token = ?");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if (!$user) { jsonResponse(["error" => "توکن نامعتبر"], 401); }
    return $user;
}

function getActiveProducts() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM products WHERE is_active = 1 ORDER BY id");
    return $stmt->fetchAll();
}
